@echo off
setlocal
cd /d "%~dp0"

REM Prefer the PHP installation already used by this project owner.
set "PHPEXE="
if exist "C:\php\php.exe" set "PHPEXE=C:\php\php.exe"
if not defined PHPEXE if exist "C:\xampp\php\php.exe" set "PHPEXE=C:\xampp\php\php.exe"
if not defined PHPEXE (
    for /f "delims=" %%P in ('where php 2^>nul') do (
        if not defined PHPEXE set "PHPEXE=%%P"
    )
)

if not defined PHPEXE (
    echo ERROR: PHP was not found.
    echo Install XAMPP or PHP, then run this file again.
    pause
    exit /b 1
)

echo Using PHP: "%PHPEXE%"
"%PHPEXE%" -r "if (!in_array('mysql', PDO::getAvailableDrivers(), true)) {fwrite(STDERR, 'ERROR: PDO MySQL driver is not enabled in this PHP installation.'.PHP_EOL); exit(1);} echo 'PDO MySQL driver: OK'.PHP_EOL;"
if errorlevel 1 (
    echo.
    echo Open the php.ini shown by: "%PHPEXE%" --ini
    echo Enable extension=pdo_mysql there, save, then run start.bat again.
    pause
    exit /b 1
)

echo.
echo Make sure MySQL is started in XAMPP Control Panel.
echo FoodHub will be available at http://localhost:8000
start "" cmd /c "timeout /t 2 /nobreak >nul & start http://localhost:8000/diagnostic.php"
"%PHPEXE%" -S localhost:8000 -t public
