#!/usr/bin/env bash
# Starts FoodHub on http://localhost:8000  (MySQL/MariaDB must be running)
cd "$(dirname "$0")"
echo "Open http://localhost:8000/setup.php the first time, then http://localhost:8000"
php -S localhost:8000 -t public
