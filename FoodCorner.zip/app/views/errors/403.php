<h1>Access denied</h1>
<p>You do not have permission to view this page. <a href="<?= e(url('home/index')) ?>">Go home</a></p>
