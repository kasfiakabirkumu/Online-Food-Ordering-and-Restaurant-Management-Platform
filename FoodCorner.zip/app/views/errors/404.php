<h1>Page not found</h1>
<p>Sorry, we could not find that page. <a href="<?= e(url('home/index')) ?>">Go home</a></p>
