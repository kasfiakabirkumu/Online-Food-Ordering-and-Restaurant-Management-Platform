<article class="card">
  <div class="card-emoji" aria-hidden="true"><?= e($item['emoji']) ?></div>
  <h3><?= e($item['name']) ?></h3>
  <p class="muted"><?= e($item['category_name']) ?></p>
  <p><?= e($item['description']) ?></p>
  <div class="card-foot">
    <strong><?= money($item['price']) ?></strong>
    <form method="post" action="<?= e(url('cart/add')) ?>" class="add-form">
      <?= csrf_field() ?>
      <input type="hidden" name="id" value="<?= (int)$item['id'] ?>">
      <button class="btn btn-sm" type="submit">Add to cart</button>
    </form>
  </div>
</article>
