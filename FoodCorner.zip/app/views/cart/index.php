<h1>Your cart</h1>
<?php if (!$lines): ?>
  <p>Your cart is empty. <a href="<?= e(url('menu/index')) ?>">Browse the menu</a></p>
<?php else: ?>
<form method="post" action="<?= e(url('cart/update')) ?>">
  <?= csrf_field() ?>
  <div class="table-wrap">
  <table>
    <thead><tr><th>Item</th><th>Price</th><th>Qty</th><th>Subtotal</th><th><span class="sr-only">Remove</span></th></tr></thead>
    <tbody>
    <?php foreach ($lines as $l): ?>
      <tr>
        <td><?= e($l['emoji']) ?> <?= e($l['name']) ?></td>
        <td><?= money($l['price']) ?></td>
        <td><input type="number" name="qty[<?= (int)$l['id'] ?>]" value="<?= (int)$l['qty'] ?>" min="0" max="20" aria-label="Quantity for <?= e($l['name']) ?>"></td>
        <td><?= money($l['subtotal']) ?></td>
        <td><button type="submit" name="remove" value="<?= (int)$l['id'] ?>" class="link-btn danger">Remove</button></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
  <button class="btn btn-secondary" type="submit">Update quantities</button>
</form>
<dl class="totals">
  <dt>Subtotal</dt><dd><?= money($subtotal) ?></dd>
  <dt>Delivery</dt><dd><?= $fee > 0 ? money($fee) : 'Free' ?></dd>
  <dt>Total</dt><dd><strong><?= money($subtotal + $fee) ?></strong></dd>
</dl>
<a class="btn" href="<?= e(url('checkout/index')) ?>">Proceed to checkout</a>
<?php endif; ?>
