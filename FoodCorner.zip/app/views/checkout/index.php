<h1>Checkout</h1>
<?php foreach ($errors as $err): ?><div class="alert alert-error" role="alert"><?= e($err) ?></div><?php endforeach; ?>
<div class="two-col">
<form method="post" action="<?= e(url('checkout/index')) ?>" novalidate id="checkout-form">
  <?= csrf_field() ?>
  <fieldset>
    <legend>Delivery details</legend>
    <label for="address">Delivery address</label>
    <textarea id="address" name="address" rows="2" required maxlength="255"><?= e($old['address']) ?></textarea>
    <label for="phone">Mobile number</label>
    <input id="phone" name="phone" type="tel" required value="<?= e($old['phone']) ?>" placeholder="01712345678">
    <label for="notes">Notes (optional)</label>
    <input id="notes" name="notes" type="text" maxlength="255" value="<?= e($old['notes']) ?>">
  </fieldset>

  <fieldset>
    <legend>Payment method</legend>
    <label class="radio"><input type="radio" name="method" value="cod" <?= $old['method'] === 'cod' ? 'checked' : '' ?>> Cash on delivery</label>
    <label class="radio"><input type="radio" name="method" value="card" <?= $old['method'] === 'card' ? 'checked' : '' ?>> Credit / debit card</label>
    <label class="radio"><input type="radio" name="method" value="bkash" <?= $old['method'] === 'bkash' ? 'checked' : '' ?>> bKash</label>

    <div class="pay-box" data-method="card">
      <p class="muted">Demo only. Use test card <code>4242 4242 4242 4242</code>, any future expiry, any 3-digit CVV. Nothing is charged.</p>
      <label for="card_name">Name on card</label>
      <input id="card_name" name="card_name" type="text" autocomplete="cc-name" value="<?= e($old['card_name']) ?>">
      <label for="card_number">Card number</label>
      <input id="card_number" name="card_number" type="text" inputmode="numeric" autocomplete="off" maxlength="23" placeholder="4242 4242 4242 4242">
      <div class="row">
        <div><label for="card_expiry">Expiry (MM/YY)</label>
        <input id="card_expiry" name="card_expiry" type="text" autocomplete="off" maxlength="5" placeholder="12/30"></div>
        <div><label for="card_cvv">CVV</label>
        <input id="card_cvv" name="card_cvv" type="password" inputmode="numeric" autocomplete="off" maxlength="4"></div>
      </div>
    </div>

    <div class="pay-box" data-method="bkash">
      <p class="muted">Demo only. Enter any bKash number and a transaction ID such as <code>8N7A6D5EE1</code>.</p>
      <label for="bkash_number">bKash number</label>
      <input id="bkash_number" name="bkash_number" type="tel" value="<?= e($old['bkash_number']) ?>" placeholder="01712345678">
      <label for="bkash_trx">Transaction ID</label>
      <input id="bkash_trx" name="bkash_trx" type="text" maxlength="12" value="<?= e($old['bkash_trx']) ?>">
    </div>
  </fieldset>
  <button class="btn" type="submit">Place order</button>
</form>

<aside class="summary">
  <h2>Order summary</h2>
  <ul class="plain">
  <?php foreach ($lines as $l): ?>
    <li><?= (int)$l['qty'] ?> × <?= e($l['name']) ?> <span class="right"><?= money($l['subtotal']) ?></span></li>
  <?php endforeach; ?>
  </ul>
  <dl class="totals">
    <dt>Subtotal</dt><dd><?= money($subtotal) ?></dd>
    <dt>Delivery</dt><dd><?= $fee > 0 ? money($fee) : 'Free' ?></dd>
    <dt>Total</dt><dd><strong><?= money($subtotal + $fee) ?></strong></dd>
  </dl>
</aside>
</div>
