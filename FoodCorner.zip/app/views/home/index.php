<section class="hero">
  <h1>Hungry? Order in minutes.</h1>
  <p>Fresh meals from our kitchen to your door. Pay by cash, card or bKash.</p>
  <a class="btn" href="<?= e(url('menu/index')) ?>">Browse the menu</a>
</section>

<h2>Categories</h2>
<ul class="chips">
  <?php foreach ($categories as $c): ?>
    <li><a href="<?= e(url('menu/index', ['category' => $c['id']])) ?>"><?= e($c['name']) ?></a></li>
  <?php endforeach; ?>
</ul>

<h2>Popular right now</h2>
<div class="grid">
  <?php foreach ($featured as $item): include BASE_PATH . '/app/views/partials/menu_card.php'; endforeach; ?>
</div>
