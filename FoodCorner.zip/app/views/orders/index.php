<h1>My orders</h1>
<?php if (!$orders): ?>
  <p>You have not placed any orders yet. <a href="<?= e(url('menu/index')) ?>">Order something tasty</a></p>
<?php else: ?>
<div class="table-wrap"><table>
  <thead><tr><th>#</th><th>Date</th><th>Total</th><th>Payment</th><th>Status</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($orders as $o): ?>
    <tr>
      <td><?= (int)$o['id'] ?></td>
      <td><?= e(date('d M Y, H:i', strtotime($o['created_at']))) ?></td>
      <td><?= money($o['total']) ?></td>
      <td><?= e(strtoupper($o['pay_method'])) ?> · <?= e($o['pay_status']) ?></td>
      <td><span class="status s-<?= e($o['status']) ?>"><?= e(str_replace('_', ' ', $o['status'])) ?></span></td>
      <td><a href="<?= e(url('order/show', ['id' => $o['id']])) ?>">View</a></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>
<?php endif; ?>
