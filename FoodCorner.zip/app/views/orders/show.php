<h1>Order #<?= (int)$order['id'] ?> <span class="status s-<?= e($order['status']) ?>"><?= e(str_replace('_', ' ', $order['status'])) ?></span></h1>
<p class="muted">Placed on <?= e(date('d M Y, H:i', strtotime($order['created_at']))) ?></p>
<div class="two-col">
  <div>
    <h2>Items</h2>
    <div class="table-wrap"><table>
      <thead><tr><th>Item</th><th>Qty</th><th>Unit price</th><th>Total</th></tr></thead>
      <tbody>
      <?php foreach ($items as $i): ?>
        <tr><td><?= e($i['emoji']) ?> <?= e($i['name']) ?></td><td><?= (int)$i['quantity'] ?></td>
        <td><?= money($i['unit_price']) ?></td><td><?= money($i['unit_price'] * $i['quantity']) ?></td></tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
    <dl class="totals">
      <dt>Subtotal</dt><dd><?= money($order['subtotal']) ?></dd>
      <dt>Delivery</dt><dd><?= $order['delivery_fee'] > 0 ? money($order['delivery_fee']) : 'Free' ?></dd>
      <dt>Total</dt><dd><strong><?= money($order['total']) ?></strong></dd>
    </dl>
  </div>
  <aside class="summary">
    <h2>Delivery</h2>
    <p><?= e($order['delivery_address']) ?><br><?= e($order['phone']) ?></p>
    <?php if ($order['notes'] !== null && $order['notes'] !== ''): ?><p>Notes: <?= e($order['notes']) ?></p><?php endif; ?>
    <h2>Payment</h2>
    <p>Method: <?= e(strtoupper($order['pay_method'])) ?><br>
    Status: <strong><?= e($order['pay_status']) ?></strong>
    <?php if ($order['card_last4']): ?><br>Card: •••• <?= e($order['card_last4']) ?><?php endif; ?>
    <?php if ($order['transaction_ref']): ?><br>Reference: <?= e($order['transaction_ref']) ?><?php endif; ?></p>
    <?php if (is_admin()): ?><p><a href="<?= e(url('admin_order/show', ['id' => $order['id']])) ?>">Manage this order</a></p><?php endif; ?>
  </aside>
</div>
