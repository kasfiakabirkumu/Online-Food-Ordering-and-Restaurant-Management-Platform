<section class="narrow">
<h1>Log in</h1>
<?php foreach ($errors as $err): ?><div class="alert alert-error" role="alert"><?= e($err) ?></div><?php endforeach; ?>
<form method="post" action="<?= e(url('auth/login')) ?>">
  <?= csrf_field() ?>
  <label for="email">E-mail</label>
  <input id="email" name="email" type="email" required autocomplete="email" value="<?= e($email) ?>">
  <label for="password">Password</label>
  <input id="password" name="password" type="password" required autocomplete="current-password">
  <label class="radio"><input type="checkbox" name="remember" value="1" <?= $remembered ? 'checked' : '' ?>> Remember my e-mail on this device (cookie)</label>
  <button class="btn" type="submit">Log in</button>
</form>
<p>New here? <a href="<?= e(url('auth/register')) ?>">Create an account</a></p>
<p class="muted">Demo: customer@foodhub.test / Customer@123 · admin@foodhub.test / Admin@123</p>
</section>
