<section class="narrow">
<h1>Create account</h1>
<?php foreach ($errors as $err): ?><div class="alert alert-error" role="alert"><?= e($err) ?></div><?php endforeach; ?>
<form method="post" action="<?= e(url('auth/register')) ?>" novalidate>
  <?= csrf_field() ?>
  <label for="name">Full name</label>
  <input id="name" name="name" type="text" required maxlength="60" value="<?= e($old['name']) ?>" autocomplete="name">
  <label for="email">E-mail</label>
  <input id="email" name="email" type="email" required maxlength="120" value="<?= e($old['email']) ?>" autocomplete="email">
  <label for="phone">Mobile number</label>
  <input id="phone" name="phone" type="tel" required value="<?= e($old['phone']) ?>" placeholder="01712345678" autocomplete="tel">
  <label for="password">Password</label>
  <input id="password" name="password" type="password" required autocomplete="new-password">
  <small class="muted">At least 8 characters with upper case, lower case and a digit.</small>
  <label for="confirm">Confirm password</label>
  <input id="confirm" name="confirm" type="password" required autocomplete="new-password">
  <button class="btn" type="submit">Register</button>
</form>
<p>Already registered? <a href="<?= e(url('auth/login')) ?>">Log in</a></p>
</section>
