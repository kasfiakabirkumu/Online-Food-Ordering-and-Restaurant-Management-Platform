<h1>Our menu</h1>
<form method="get" action="index.php" class="filters" id="filter-form">
  <input type="hidden" name="r" value="menu/index">
  <label for="q" class="sr-only">Search</label>
  <input type="search" id="q" name="q" placeholder="Search dishes..." value="<?= e($q) ?>" maxlength="60">
  <label for="category" class="sr-only">Category</label>
  <select id="category" name="category">
    <option value="0">All categories</option>
    <?php foreach ($categories as $c): ?>
      <option value="<?= (int)$c['id'] ?>" <?= $categoryId === (int)$c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
    <?php endforeach; ?>
  </select>
  <button class="btn" type="submit">Search</button>
</form>
<p class="muted" id="result-count"><?= count($items) ?> item(s) found</p>
<div class="grid" id="menu-grid">
  <?php foreach ($items as $item): include BASE_PATH . '/app/views/partials/menu_card.php'; endforeach; ?>
  <?php if (!$items): ?><p>No dishes match your search.</p><?php endif; ?>
</div>
