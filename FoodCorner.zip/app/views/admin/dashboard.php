<?php include __DIR__ . '/_nav.php'; ?>
<h1>Admin dashboard</h1>
<div class="stats">
  <div class="stat"><span><?= (int)$stats['orders'] ?></span>Total orders</div>
  <div class="stat"><span><?= (int)$stats['pending'] ?></span>Pending orders</div>
  <div class="stat"><span><?= money($stats['revenue']) ?></span>Paid revenue</div>
  <div class="stat"><span><?= (int)$stats['customers'] ?></span>Customers</div>
  <div class="stat"><span><?= (int)$stats['items'] ?></span>Menu items</div>
</div>
<h2>Recent orders</h2>
<?php include __DIR__ . '/_orders_table.php'; ?>
