<nav class="subnav" aria-label="Admin navigation">
  <a href="<?= e(url('admin/dashboard')) ?>">Dashboard</a>
  <a href="<?= e(url('admin_order/index')) ?>">Orders</a>
  <a href="<?= e(url('admin_menu/index')) ?>">Menu items</a>
  <a href="<?= e(url('admin_category/index')) ?>">Categories</a>
</nav>
