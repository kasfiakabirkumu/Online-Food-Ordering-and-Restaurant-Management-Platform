<?php $rows = $orders ?? $recent ?? []; ?>
<?php if (!$rows): ?>
  <p>No orders yet.</p>
<?php else: ?>
<div class="table-wrap"><table>
  <thead><tr><th>#</th><th>Customer</th><th>Date</th><th>Total</th><th>Payment</th><th>Status</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($rows as $o): ?>
    <tr>
      <td><?= (int)$o['id'] ?></td>
      <td><?= e($o['customer']) ?></td>
      <td><?= e(date('d M Y, H:i', strtotime($o['created_at']))) ?></td>
      <td><?= money($o['total']) ?></td>
      <td><?= e(strtoupper($o['pay_method'])) ?> · <?= e($o['pay_status']) ?></td>
      <td><span class="status s-<?= e($o['status']) ?>"><?= e(str_replace('_', ' ', $o['status'])) ?></span></td>
      <td><a href="<?= e(url('admin_order/show', ['id' => $o['id']])) ?>">Open</a></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>
<?php endif; ?>
