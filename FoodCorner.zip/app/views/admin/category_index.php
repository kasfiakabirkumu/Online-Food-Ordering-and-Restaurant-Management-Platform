<?php include __DIR__ . '/_nav.php'; ?>
<h1>Categories</h1>
<p><a class="btn" href="<?= e(url('admin_category/form')) ?>">+ Add category</a></p>
<div class="table-wrap"><table>
  <thead><tr><th>Name</th><th>Description</th><th>Items</th><th>Actions</th></tr></thead>
  <tbody>
  <?php foreach ($categories as $c): ?>
    <tr>
      <td><?= e($c['name']) ?></td>
      <td><?= e($c['description']) ?></td>
      <td><?= (int)$c['item_count'] ?></td>
      <td class="actions">
        <a href="<?= e(url('admin_category/form', ['id' => $c['id']])) ?>">Edit</a>
        <form method="post" action="<?= e(url('admin_category/delete')) ?>" class="inline confirm-form" data-confirm="Delete this category?">
          <?= csrf_field() ?>
          <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
          <button type="submit" class="link-btn danger">Delete</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>
