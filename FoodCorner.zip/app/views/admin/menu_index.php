<?php include __DIR__ . '/_nav.php'; ?>
<h1>Menu items</h1>
<p><a class="btn" href="<?= e(url('admin_menu/form')) ?>">+ Add menu item</a></p>
<div class="table-wrap"><table>
  <thead><tr><th>Item</th><th>Category</th><th>Price</th><th>Available</th><th>Actions</th></tr></thead>
  <tbody>
  <?php foreach ($items as $i): ?>
    <tr>
      <td><?= e($i['emoji']) ?> <?= e($i['name']) ?></td>
      <td><?= e($i['category_name']) ?></td>
      <td><?= money($i['price']) ?></td>
      <td><?= $i['is_available'] ? 'Yes' : 'No' ?></td>
      <td class="actions">
        <a href="<?= e(url('admin_menu/form', ['id' => $i['id']])) ?>">Edit</a>
        <form method="post" action="<?= e(url('admin_menu/delete')) ?>" class="inline confirm-form" data-confirm="Delete this menu item?">
          <?= csrf_field() ?>
          <input type="hidden" name="id" value="<?= (int)$i['id'] ?>">
          <button type="submit" class="link-btn danger">Delete</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>
