<?php include __DIR__ . '/_nav.php'; ?>
<h1>Orders</h1>
<form method="get" action="index.php" class="filters">
  <input type="hidden" name="r" value="admin_order/index">
  <label for="status" class="sr-only">Status</label>
  <select id="status" name="status">
    <option value="">All statuses</option>
    <?php foreach (Order::STATUSES as $s): ?>
      <option value="<?= e($s) ?>" <?= $status === $s ? 'selected' : '' ?>><?= e(str_replace('_', ' ', $s)) ?></option>
    <?php endforeach; ?>
  </select>
  <button class="btn btn-secondary" type="submit">Filter</button>
</form>
<?php include __DIR__ . '/_orders_table.php'; ?>
