<?php include __DIR__ . '/_nav.php'; ?>
<h1><?= $item['id'] ? 'Edit menu item' : 'Add menu item' ?></h1>
<?php foreach ($errors as $err): ?><div class="alert alert-error" role="alert"><?= e($err) ?></div><?php endforeach; ?>
<form method="post" action="<?= e(url('admin_menu/save')) ?>" class="narrow" novalidate>
  <?= csrf_field() ?>
  <input type="hidden" name="id" value="<?= (int)$item['id'] ?>">
  <label for="name">Name</label>
  <input id="name" name="name" type="text" required maxlength="80" value="<?= e($item['name']) ?>">
  <label for="description">Description</label>
  <input id="description" name="description" type="text" maxlength="255" value="<?= e($item['description']) ?>">
  <label for="category_id">Category</label>
  <select id="category_id" name="category_id" required>
    <option value="0">Choose...</option>
    <?php foreach ($categories as $c): ?>
      <option value="<?= (int)$c['id'] ?>" <?= (int)$item['category_id'] === (int)$c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
    <?php endforeach; ?>
  </select>
  <label for="price">Price (৳)</label>
  <input id="price" name="price" type="text" inputmode="decimal" required value="<?= e($item['price']) ?>">
  <label for="emoji">Emoji icon</label>
  <input id="emoji" name="emoji" type="text" maxlength="4" value="<?= e($item['emoji']) ?>">
  <label class="radio"><input type="checkbox" name="is_available" value="1" <?= $item['is_available'] ? 'checked' : '' ?>> Available to order</label>
  <button class="btn" type="submit">Save</button>
  <a href="<?= e(url('admin_menu/index')) ?>">Cancel</a>
</form>
