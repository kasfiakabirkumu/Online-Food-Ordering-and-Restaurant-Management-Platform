<?php include __DIR__ . '/_nav.php'; ?>
<h1><?= $cat['id'] ? 'Edit category' : 'Add category' ?></h1>
<?php foreach ($errors as $err): ?><div class="alert alert-error" role="alert"><?= e($err) ?></div><?php endforeach; ?>
<form method="post" action="<?= e(url('admin_category/save')) ?>" class="narrow" novalidate>
  <?= csrf_field() ?>
  <input type="hidden" name="id" value="<?= (int)$cat['id'] ?>">
  <label for="name">Name</label>
  <input id="name" name="name" type="text" required maxlength="60" value="<?= e($cat['name']) ?>">
  <label for="description">Description</label>
  <input id="description" name="description" type="text" maxlength="255" value="<?= e($cat['description']) ?>">
  <button class="btn" type="submit">Save</button>
  <a href="<?= e(url('admin_category/index')) ?>">Cancel</a>
</form>
