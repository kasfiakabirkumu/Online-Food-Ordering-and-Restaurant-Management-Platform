<?php include __DIR__ . '/_nav.php'; ?>
<h1>Order #<?= (int)$order['id'] ?></h1>
<p>Customer: <strong><?= e($order['customer']) ?></strong> (<?= e($order['email']) ?>)</p>
<div class="two-col">
  <div>
    <div class="table-wrap"><table>
      <thead><tr><th>Item</th><th>Qty</th><th>Unit price</th><th>Total</th></tr></thead>
      <tbody>
      <?php foreach ($items as $i): ?>
        <tr><td><?= e($i['emoji']) ?> <?= e($i['name']) ?></td><td><?= (int)$i['quantity'] ?></td>
        <td><?= money($i['unit_price']) ?></td><td><?= money($i['unit_price'] * $i['quantity']) ?></td></tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
    <dl class="totals">
      <dt>Subtotal</dt><dd><?= money($order['subtotal']) ?></dd>
      <dt>Delivery</dt><dd><?= money($order['delivery_fee']) ?></dd>
      <dt>Total</dt><dd><strong><?= money($order['total']) ?></strong></dd>
    </dl>
  </div>
  <aside class="summary">
    <p><?= e($order['delivery_address']) ?><br><?= e($order['phone']) ?></p>
    <p>Payment: <?= e(strtoupper($order['pay_method'])) ?> · <strong><?= e($order['pay_status']) ?></strong>
    <?php if ($order['transaction_ref']): ?><br>Ref: <?= e($order['transaction_ref']) ?><?php endif; ?></p>
    <form method="post" action="<?= e(url('admin_order/status')) ?>">
      <?= csrf_field() ?>
      <input type="hidden" name="id" value="<?= (int)$order['id'] ?>">
      <label for="status">Update status</label>
      <select id="status" name="status">
        <?php foreach (Order::STATUSES as $s): ?>
          <option value="<?= e($s) ?>" <?= $order['status'] === $s ? 'selected' : '' ?>><?= e(str_replace('_', ' ', $s)) ?></option>
        <?php endforeach; ?>
      </select>
      <button class="btn" type="submit">Save status</button>
    </form>
    <form method="post" action="<?= e(url('admin_order/delete')) ?>" class="confirm-form" data-confirm="Delete this order permanently?">
      <?= csrf_field() ?>
      <input type="hidden" name="id" value="<?= (int)$order['id'] ?>">
      <button class="btn btn-danger" type="submit">Delete order</button>
    </form>
  </aside>
</div>
