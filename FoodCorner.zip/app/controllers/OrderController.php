<?php
declare(strict_types=1);

class OrderController extends Controller
{
    public function index(): void
    {
        $user = $this->requireLogin();
        $this->render('orders/index', ['orders' => Order::forUser($user['id'])], 'My orders');
    }

    public function show(): void
    {
        $user = $this->requireLogin();
        $order = Order::find((int)($_GET['id'] ?? 0));
        // Access control: customers can only see their own orders.
        if (!$order || ($order['user_id'] != $user['id'] && $user['role'] !== 'admin')) {
            (new HomeController())->notFound();
            return;
        }
        $this->render('orders/show', ['order' => $order, 'items' => Order::items((int)$order['id'])], 'Order #' . $order['id']);
    }
}
